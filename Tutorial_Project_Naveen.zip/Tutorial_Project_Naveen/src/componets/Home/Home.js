//import backimage from './start-a-blog-cover.jpeg';
import backimage from './laptop.jpg';
import './Home.css';
function Home(){
    return(
        <img src={backimage} alt="Image Not Found"/>
    )
}
export default Home;